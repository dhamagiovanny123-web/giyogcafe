<?php
// Disable error display, handle manually
error_reporting(0);
ini_set('display_errors', 0);

echo "<!DOCTYPE html>
<html>
<head>
    <title>MySQL Diagnostic</title>
    <style>
        body { font-family: Arial, sans-serif; padding: 20px; background: #f5f5f5; }
        .container { max-width: 800px; margin: 0 auto; background: white; padding: 30px; border-radius: 10px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
        h2 { color: #1e40af; }
        h3 { color: #3b82f6; margin-top: 20px; }
        .success { color: #10b981; }
        .error { color: #ef4444; }
        .warning { background: #fffbeb; padding: 15px; border-left: 4px solid #f59e0b; margin: 20px 0; }
        .info { background: #f0f9ff; padding: 15px; border-left: 4px solid #3b82f6; margin: 20px 0; }
        ul { line-height: 2; }
        code { background: #f3f4f6; padding: 2px 6px; border-radius: 3px; }
    </style>
</head>
<body>
<div class='container'>";

echo "<h2>🔍 MySQL Connection Diagnostic</h2>";

// Test 1: Cek Extension
echo "<h3>1. Check MySQLi Extension</h3>";
if (extension_loaded('mysqli')) {
    echo "<span class='success'>✅ MySQLi extension is loaded</span><br>";
} else {
    echo "<span class='error'>❌ MySQLi extension NOT loaded - Check php.ini</span><br>";
    echo "</div></body></html>";
    exit;
}

// Test 2: Try different ports
echo "<h3>2. Testing MySQL Connections</h3>";
$ports_to_test = [3306, 3307, 3308, 3309];
$host = 'localhost';
$user = 'root';
$pass = '';
$connected = false;

foreach ($ports_to_test as $port) {
    echo "Testing port <strong>$port</strong>... ";
    
    try {
        // Suppress errors with @ and try-catch
        mysqli_report(MYSQLI_REPORT_OFF);
        $conn = @new mysqli($host, $user, $pass, '', $port);
        
        if ($conn->connect_error) {
            echo "<span class='error'>❌ Failed: " . htmlspecialchars($conn->connect_error) . "</span><br>";
        } else {
            echo "<span class='success'>✅ <strong>SUCCESS!</strong> MySQL is running on port $port</span><br>";
            echo "MySQL Version: <strong>" . $conn->server_info . "</strong><br>";
            
            // List databases
            echo "<h4>Databases:</h4><ul>";
            $result = $conn->query("SHOW DATABASES");
            if ($result) {
                while ($row = $result->fetch_array()) {
                    $db_name = htmlspecialchars($row[0]);
                    if ($db_name === 'umkm_pos') {
                        echo "<li><strong style='color: #10b981;'>$db_name ✓</strong></li>";
                    } else {
                        echo "<li>$db_name</li>";
                    }
                }
            }
            echo "</ul>";
            
            $conn->close();
            echo "<div class='info'><strong>✅ MySQL berhasil terkoneksi!</strong><br>";
            echo "Update <code>db.php</code> dengan port: <strong>$port</strong></div>";
            $connected = true;
            break;
        }
    } catch (Exception $e) {
        echo "<span class='error'>❌ Exception: " . htmlspecialchars($e->getMessage()) . "</span><br>";
    }
}

if (!$connected) {
    echo "<div class='warning'>";
    echo "<strong>⚠️ MySQL TIDAK RUNNING!</strong><br><br>";
    echo "Semua port gagal terkoneksi. MySQL di XAMPP belum dijalankan.";
    echo "</div>";
    
    echo "<h3>3. Cara Menjalankan MySQL:</h3>";
    echo "<div class='info'>";
    echo "<ol>";
    echo "<li><strong>Buka XAMPP Control Panel</strong></li>";
    echo "<li>Cari baris <strong>MySQL</strong></li>";
    echo "<li>Klik tombol <strong>Start</strong> (harus berubah jadi hijau)</li>";
    echo "<li>Tunggu sampai status berubah menjadi <span style='color: green; font-weight: bold;'>Running</span></li>";
    echo "<li>Refresh halaman ini</li>";
    echo "</ol>";
    echo "</div>";
    
    echo "<h3>4. Jika MySQL Tidak Bisa Start:</h3>";
    echo "<div class='warning'>";
    echo "<strong>Kemungkinan Penyebab:</strong><ul>";
    echo "<li><strong>Port 3306 digunakan aplikasi lain</strong> (MySQL lain, PostgreSQL, dll)</li>";
    echo "<li><strong>Service MySQL sudah running di background</strong></li>";
    echo "<li><strong>XAMPP tidak dijalankan sebagai Administrator</strong></li>";
    echo "</ul>";
    echo "<strong>Solusi:</strong><ul>";
    echo "<li>Buka <strong>Task Manager</strong> (Ctrl+Shift+Esc)</li>";
    echo "<li>Tab <strong>Services</strong> → Cari <code>mysql</code> atau <code>mysqld</code></li>";
    echo "<li>Stop service yang bentrok</li>";
    echo "<li>Atau ganti port MySQL di XAMPP: <code>Config → my.ini → port=3307</code></li>";
    echo "<li>Restart XAMPP sebagai Administrator</li>";
    echo "</ul>";
    echo "</div>";
} else {
    echo "<h3>3. Next Steps:</h3>";
    echo "<div class='info'>";
    echo "<ol>";
    echo "<li>✅ MySQL sudah running dengan baik!</li>";
    echo "<li>Database <strong>umkm_pos</strong> " . (strpos(ob_get_contents(), 'umkm_pos') !== false ? "sudah ada" : "akan dibuat otomatis") . "</li>";
    echo "<li>Kembali ke aplikasi: <a href='login.php'>Login Page</a></li>";
    echo "</ol>";
    echo "</div>";
}

echo "<div style='text-align: center; margin-top: 30px;'>";
echo "<a href='check_mysql.php' style='display: inline-block; padding: 10px 20px; background: #3b82f6; color: white; text-decoration: none; border-radius: 5px;'>🔄 Refresh</a> ";
echo "<a href='index.php' style='display: inline-block; padding: 10px 20px; background: #10b981; color: white; text-decoration: none; border-radius: 5px; margin-left: 10px;'>🏠 Home</a>";
echo "</div>";

echo "</div></body></html>";
?>