document.addEventListener('DOMContentLoaded', () => {
    init();
});

function init() {
    loadProduk();
    loadPelanggan();
    loadPenjualan();
    renderCart();

    const hash = window.location.hash.substring(1);
    if (hash) {
        const btn = document.querySelector(`[onclick*="'${hash}'"]`);
        if (btn) showTab(hash, { target: btn });
    }
}

/* generic API -> api.php */
async function api(action, data = {}) {
    try {
        const fd = new FormData();
        fd.append('action', action);
        for (let k in data) fd.append(k, data[k]);
        
        const res = await fetch('api.php', { 
            method: 'POST', 
            body: fd 
        });
        
        if (!res.ok) {
            console.error('HTTP Error:', res.status, res.statusText);
            throw new Error(`HTTP Error: ${res.status}`);
        }
        
        const contentType = res.headers.get("content-type");
        if (!contentType || !contentType.includes("application/json")) {
            const text = await res.text();
            console.error('Non-JSON response:', text);
            throw new Error('Server returned non-JSON response');
        }
        
        const json = await res.json();
        
        if (!json.success && json.error) {
            console.error('Server Error:', json.error);
        }
        
        return json;
    } catch (error) {
        console.error('API Error:', error);
        return { 
            success: false, 
            message: error.message || 'Terjadi kesalahan koneksi' 
        };
    }
}

/* TAB switching */
function showTab(tabId, evt) {
    document.querySelectorAll('.tab-content').forEach(t => t.classList.remove('active'));
    document.querySelectorAll('.nav-btn').forEach(b => b.classList.remove('active'));
    
    const tab = document.getElementById('tab-' + tabId);
    if (tab) tab.classList.add('active');
    if (evt && evt.target) evt.target.classList.add('active');
    
    window.location.hash = tabId;
}

/* Produk */
let produkList = [];
async function loadProduk() {
    try {
        const res = await api('get_produk');
        if (res.success) {
            produkList = res.data || [];
            renderProdukGrid();
            renderProdukTable();
        } else {
            const errorMsg = res.error || res.message || 'Unknown error';
            console.error('Load produk failed:', errorMsg);
            showToast('Gagal memuat produk: ' + errorMsg, true);
            produkList = [];
            renderProdukGrid();
            renderProdukTable();
        }
    } catch (error) {
        console.error('Load produk exception:', error);
        showToast('Gagal memuat produk: ' + error.message, true);
        produkList = [];
    }
}

function getProductEmoji(namaProduk) {
    const nama = namaProduk.toLowerCase();
    
    // Makanan
    if (nama.includes('nasi') || nama.includes('rice')) return '🍚';
    if (nama.includes('mie') || nama.includes('noodle')) return '🍜';
    if (nama.includes('ayam') || nama.includes('chicken')) return '🍗';
    if (nama.includes('sate') || nama.includes('satay')) return '🍢';
    if (nama.includes('burger')) return '🍔';
    if (nama.includes('pizza')) return '🍕';
    if (nama.includes('roti') || nama.includes('bread')) return '🍞';
    
    // Minuman
    if (nama.includes('kopi') || nama.includes('coffee')) return '☕';
    if (nama.includes('teh') || nama.includes('tea')) return '🍵';
    if (nama.includes('jus') || nama.includes('juice')) return '🧃';
    if (nama.includes('susu') || nama.includes('milk')) return '🥛';
    if (nama.includes('es krim') || nama.includes('ice cream')) return '🍦';
    if (nama.includes('smoothie')) return '🥤';
    
    // Snack
    if (nama.includes('kentang') || nama.includes('potato') || nama.includes('fries')) return '🍟';
    if (nama.includes('donat') || nama.includes('donut')) return '🍩';
    if (nama.includes('kue') || nama.includes('cake')) return '🍰';
    if (nama.includes('cookie') || nama.includes('biskuit')) return '🍪';
    
    // Default
    return '📦';
}

function renderProdukGrid() {
    const grid = document.getElementById('produkGrid');
    if (!grid) return;
    
    const q = (document.getElementById('searchProduk')?.value || '').toLowerCase();
    const filtered = produkList.filter(p => 
        p.nama_produk.toLowerCase().includes(q)
    );
    
    if (filtered.length === 0) {
        grid.innerHTML = '<div style="grid-column: 1/-1; text-align: center; padding: 2rem; color: #64748b;">Tidak ada produk</div>';
        return;
    }
    
    grid.innerHTML = filtered.map(p => `
        <div class="product-card ${p.stok === 0 ? 'out-of-stock' : ''}" onclick="${p.stok > 0 ? `addToCart(${p.produk_id})` : ''}">
            <div class="product-image">${getProductEmoji(p.nama_produk)}</div>
            <div class="product-name">${escapeHtml(p.nama_produk)}</div>
            <div class="product-price">${formatRupiah(p.harga)}</div>
            <div class="product-stock">Stok: ${p.stok}</div>
        </div>
    `).join('');
}

function renderProdukTable() {
    const tbody = document.getElementById('produkTable');
    if (!tbody) return;
    
    if (produkList.length === 0) {
        tbody.innerHTML = '<tr><td colspan="4" style="text-align: center; padding: 2rem; color: #64748b;">Tidak ada data produk</td></tr>';
        return;
    }
    
    tbody.innerHTML = produkList.map(p => `
        <tr>
            <td>${escapeHtml(p.nama_produk)}</td>
            <td class="text-right">${formatRupiah(p.harga)}</td>
            <td class="text-center">${p.stok}</td>
            <td class="text-center">
                <button class="btn btn-edit btn-sm" onclick="editProduk(${p.produk_id})">Edit</button>
                <button class="btn btn-delete btn-sm" onclick="deleteProduk(${p.produk_id})">Hapus</button>
            </td>
        </tr>
    `).join('');
}

function editProduk(id) {
    const p = produkList.find(x => x.produk_id == id);
    if (!p) return;
    document.getElementById('produkId').value = p.produk_id;
    document.getElementById('namaProduk').value = p.nama_produk;
    document.getElementById('hargaProduk').value = p.harga;
    document.getElementById('stokProduk').value = p.stok;
    document.getElementById('modalProdukTitle').textContent = 'Edit Produk';
    showModal('modalProduk');
}

async function saveProduk(e) {
    e.preventDefault();
    const id = document.getElementById('produkId').value;
    const nama = document.getElementById('namaProduk').value.trim();
    const harga = parseFloat(document.getElementById('hargaProduk').value);
    const stok = parseInt(document.getElementById('stokProduk').value);
    
    if (!nama) {
        showToast('Nama produk harus diisi', true);
        return;
    }
    
    if (harga <= 0) {
        showToast('Harga harus lebih dari 0', true);
        return;
    }
    
    if (stok < 0) {
        showToast('Stok tidak boleh negatif', true);
        return;
    }
    
    const action = id ? 'update_produk' : 'add_produk';
    const data = { nama_produk: nama, harga, stok };
    if (id) data.produk_id = id;
    
    const res = await api(action, data);
    showToast(res.message, !res.success);
    
    if (res.success) {
        hideModal('modalProduk');
        document.getElementById('formProduk').reset();
        document.getElementById('produkId').value = '';
        document.getElementById('modalProdukTitle').textContent = 'Tambah Produk';
        loadProduk();
    }
}

async function deleteProduk(id) {
    if (!confirm('Yakin ingin menghapus produk ini?')) return;
    const res = await api('delete_produk', { produk_id: id });
    showToast(res.message, !res.success);
    if (res.success) loadProduk();
}

/* Pelanggan */
let pelangganList = [];
async function loadPelanggan() {
    try {
        const res = await api('get_pelanggan');
        if (res.success) {
            pelangganList = res.data || [];
            renderPelangganTable();
            renderPelangganSelect();
        } else {
            const errorMsg = res.error || res.message || 'Unknown error';
            console.error('Load pelanggan failed:', errorMsg);
            showToast('Gagal memuat pelanggan: ' + errorMsg, true);
            pelangganList = [];
        }
    } catch (error) {
        console.error('Load pelanggan exception:', error);
        showToast('Gagal memuat pelanggan: ' + error.message, true);
        pelangganList = [];
    }
}

function renderPelangganTable() {
    const tbody = document.getElementById('pelangganTable');
    if (!tbody) return;
    
    if (pelangganList.length === 0) {
        tbody.innerHTML = '<tr><td colspan="4" style="text-align: center; padding: 2rem; color: #64748b;">Tidak ada data pelanggan</td></tr>';
        return;
    }
    
    tbody.innerHTML = pelangganList.map(p => `
        <tr>
            <td>${escapeHtml(p.nama_pelanggan)}</td>
            <td>${escapeHtml(p.nomor_telepon || '-')}</td>
            <td>${escapeHtml(p.alamat || '-')}</td>
            <td class="text-center">
                <button class="btn btn-edit btn-sm" onclick="editPelanggan(${p.pelanggan_id})">Edit</button>
                <button class="btn btn-delete btn-sm" onclick="deletePelanggan(${p.pelanggan_id})">Hapus</button>
            </td>
        </tr>
    `).join('');
}

function renderPelangganSelect() {
    const sel = document.getElementById('selectPelanggan');
    if (!sel) return;
    sel.innerHTML = '<option value="">Pelanggan Umum</option>' + 
        pelangganList.map(p => `<option value="${p.pelanggan_id}">${escapeHtml(p.nama_pelanggan)}</option>`).join('');
}

function editPelanggan(id) {
    const p = pelangganList.find(x => x.pelanggan_id == id);
    if (!p) return;
    document.getElementById('pelangganId').value = p.pelanggan_id;
    document.getElementById('namaPelanggan').value = p.nama_pelanggan;
    document.getElementById('telpPelanggan').value = p.nomor_telepon || '';
    document.getElementById('alamatPelanggan').value = p.alamat || '';
    document.getElementById('modalPelangganTitle').textContent = 'Edit Pelanggan';
    showModal('modalPelanggan');
}

async function savePelanggan(e) {
    e.preventDefault();
    const id = document.getElementById('pelangganId').value;
    const nama = document.getElementById('namaPelanggan').value.trim();
    const telp = document.getElementById('telpPelanggan').value.trim();
    const alamat = document.getElementById('alamatPelanggan').value.trim();
    
    if (!nama) {
        showToast('Nama pelanggan harus diisi', true);
        return;
    }
    
    const action = id ? 'update_pelanggan' : 'add_pelanggan';
    const data = { nama_pelanggan: nama, nomor_telepon: telp, alamat };
    if (id) data.pelanggan_id = id;
    
    const res = await api(action, data);
    showToast(res.message, !res.success);
    
    if (res.success) {
        hideModal('modalPelanggan');
        document.getElementById('formPelanggan').reset();
        document.getElementById('pelangganId').value = '';
        document.getElementById('modalPelangganTitle').textContent = 'Tambah Pelanggan';
        loadPelanggan();
    }
}

async function deletePelanggan(id) {
    if (!confirm('Yakin ingin menghapus pelanggan ini?')) return;
    const res = await api('delete_pelanggan', { pelanggan_id: id });
    showToast(res.message, !res.success);
    if (res.success) loadPelanggan();
}

/* Cart */
let cart = [];
function addToCart(produkId) {
    const produk = produkList.find(p => p.produk_id == produkId);
    if (!produk) return;
    if (produk.stok <= 0) {
        showToast('Stok habis!', true);
        return;
    }
    
    const exist = cart.find(c => c.produk_id == produkId);
    if (exist) {
        if (exist.jumlah >= produk.stok) {
            showToast('Stok tidak mencukupi!', true);
            return;
        }
        exist.jumlah++;
        exist.subtotal = exist.jumlah * exist.harga;
    } else {
        cart.push({
            produk_id: produk.produk_id,
            nama_produk: produk.nama_produk,
            harga: parseFloat(produk.harga),
            jumlah: 1,
            subtotal: parseFloat(produk.harga)
        });
    }
    renderCart();
}

function updateQty(produkId, delta) {
    const item = cart.find(c => c.produk_id == produkId);
    if (!item) return;
    
    const produk = produkList.find(p => p.produk_id == produkId);
    if (!produk) return;
    
    const newQty = item.jumlah + delta;
    if (newQty <= 0) {
        removeFromCart(produkId);
        return;
    }
    
    if (newQty > produk.stok) {
        showToast('Stok tidak mencukupi!', true);
        return;
    }
    
    item.jumlah = newQty;
    item.subtotal = item.jumlah * item.harga;
    renderCart();
}

function removeFromCart(produkId) {
    cart = cart.filter(c => c.produk_id != produkId);
    renderCart();
}

function renderCart() {
    const container = document.getElementById('cartItems');
    const totalEl = document.getElementById('totalAmount');
    const checkoutBtn = document.getElementById('checkoutBtn');
    
    if (!container) return;
    
    if (cart.length === 0) {
        container.innerHTML = '<div class="cart-empty">Keranjang kosong</div>';
        if (totalEl) totalEl.textContent = 'Rp 0';
        if (checkoutBtn) checkoutBtn.disabled = true;
        return;
    }
    
    const total = cart.reduce((sum, item) => sum + item.subtotal, 0);
    
    container.innerHTML = cart.map(item => `
        <div class="cart-item">
            <div class="cart-item-info">
                <div class="cart-item-name">${escapeHtml(item.nama_produk)}</div>
                <div class="cart-item-price">${formatRupiah(item.harga)}</div>
            </div>
            <div class="cart-item-actions">
                <button class="qty-btn" onclick="updateQty(${item.produk_id}, -1)">-</button>
                <span class="qty">${item.jumlah}</span>
                <button class="qty-btn" onclick="updateQty(${item.produk_id}, 1)">+</button>
                <button class="remove-btn" onclick="removeFromCart(${item.produk_id})">🗑️</button>
            </div>
            <div class="cart-item-subtotal">${formatRupiah(item.subtotal)}</div>
        </div>
    `).join('');
    
    if (totalEl) totalEl.textContent = formatRupiah(total);
    if (checkoutBtn) checkoutBtn.disabled = false;
}

/* Checkout - DENGAN KONFIRMASI */
let checkoutTotalAmount = 0;

function checkout() {
    if (cart.length === 0) {
        showToast('Keranjang kosong!', true);
        return;
    }

    // Validasi stok
    for (let item of cart) {
        const produk = produkList.find(p => p.produk_id === item.produk_id);
        if (!produk || produk.stok < item.jumlah) {
            showToast(`Stok ${item.nama_produk} tidak mencukupi!`, true);
            return;
        }
    }

    // Hitung total
    checkoutTotalAmount = cart.reduce((sum, item) => sum + item.subtotal, 0);
    
    // Set total di modal
    document.getElementById('checkoutTotal').textContent = formatRupiah(checkoutTotalAmount);
    document.getElementById('inputBayar').value = '';
    document.getElementById('kembalianAmount').textContent = 'Rp 0';
    document.getElementById('metodePembayaran').value = 'cash';
    document.getElementById('btnProses').disabled = true;
    document.getElementById('btnProses').style.opacity = '0.5';
    
    // Hide QR container by default
    document.getElementById('qrisContainer').style.display = 'none';
    document.getElementById('cashPayment').style.display = 'block';
    
    showModal('modalKonfirmasi');
    
    // Focus dan auto select input
    setTimeout(() => {
        document.getElementById('inputBayar').focus();
        document.getElementById('inputBayar').select();
    }, 100);
}

function hitungKembalian() {
    const inputBayar = document.getElementById('inputBayar');
    const bayar = parseFloat(inputBayar.value) || 0;
    const kembalian = bayar - checkoutTotalAmount;
    
    const kembalianElement = document.getElementById('kembalianAmount');
    const btnProses = document.getElementById('btnProses');
    
    if (bayar >= checkoutTotalAmount) {
        // Uang cukup
        kembalianElement.textContent = formatRupiah(kembalian);
        kembalianElement.style.color = '#10b981';
        btnProses.disabled = false;
        btnProses.style.opacity = '1';
        btnProses.style.cursor = 'pointer';
    } else if (bayar > 0) {
        // Uang kurang
        kembalianElement.textContent = 'Uang kurang ' + formatRupiah(Math.abs(kembalian));
        kembalianElement.style.color = '#ef4444';
        btnProses.disabled = true;
        btnProses.style.opacity = '0.5';
        btnProses.style.cursor = 'not-allowed';
    } else {
        // Belum input
        kembalianElement.textContent = 'Rp 0';
        kembalianElement.style.color = '#94a3b8';
        btnProses.disabled = true;
        btnProses.style.opacity = '0.5';
        btnProses.style.cursor = 'not-allowed';
    }
}

function setQuickAmount(amount) {
    document.getElementById('inputBayar').value = amount;
    hitungKembalian();
}

function changeMetodePembayaran() {
    const metode = document.getElementById('metodePembayaran').value;
    const qrisContainer = document.getElementById('qrisContainer');
    const cashPayment = document.getElementById('cashPayment');
    const btnProses = document.getElementById('btnProses');
    
    if (metode === 'qris') {
        // Show QR Code
        qrisContainer.style.display = 'block';
        cashPayment.style.display = 'none';
        btnProses.disabled = false;
        btnProses.style.opacity = '1';
        btnProses.style.cursor = 'pointer';
        btnProses.textContent = '✓ Konfirmasi Pembayaran QRIS';
        
        // Generate QR Code
        generateQRCode();
    } else {
        // Show Cash Payment
        qrisContainer.style.display = 'none';
        cashPayment.style.display = 'block';
        btnProses.textContent = '✓ Proses Pembayaran';
        
        // Reset input dan validasi
        document.getElementById('inputBayar').value = '';
        hitungKembalian();
        
        // Focus input
        setTimeout(() => {
            document.getElementById('inputBayar').focus();
        }, 100);
    }
}

function generateQRCode() {
    const qrContainer = document.getElementById('qrcode');
    qrContainer.innerHTML = '';
    
    // Data untuk QR Code (format QRIS Indonesia)
    const merchantId = 'ID1234567890';
    const merchantName = 'GIYOGCAFE';
    const qrData = `00020101021126580011${merchantId}0303UMI52045814530336054${checkoutTotalAmount.toFixed(0)}5802ID5915${merchantName}6007JAKARTA61051234062070703A0163044C4C`;
    
    // Generate QR Code
    const qrApiUrl = `https://api.qrserver.com/v1/create-qr-code/?size=250x250&data=${encodeURIComponent(qrData)}`;
    
    const img = document.createElement('img');
    img.src = qrApiUrl;
    img.alt = 'QR Code QRIS';
    img.style.width = '100%';
    img.style.height = 'auto';
    img.style.borderRadius = '8px';
    
    qrContainer.appendChild(img);
    
    // Start countdown timer
    startQRISTimer();
}

let qrisTimerInterval;
function startQRISTimer() {
    let timeLeft = 300; // 5 minutes
    const timerElement = document.getElementById('qrisTimer');
    
    // Clear previous timer
    if (qrisTimerInterval) {
        clearInterval(qrisTimerInterval);
    }
    
    timerElement.style.color = '#10b981';
    
    qrisTimerInterval = setInterval(() => {
        timeLeft--;
        
        const minutes = Math.floor(timeLeft / 60);
        const seconds = timeLeft % 60;
        
        timerElement.textContent = `${minutes}:${seconds.toString().padStart(2, '0')}`;
        
        if (timeLeft <= 0) {
            clearInterval(qrisTimerInterval);
            timerElement.textContent = 'Waktu habis!';
            timerElement.style.color = '#ef4444';
            showToast('QR Code expired. Silakan generate ulang.', true);
        } else if (timeLeft <= 60) {
            timerElement.style.color = '#f59e0b';
        }
    }, 1000);
}

async function prosesCheckout() {
    const metode = document.getElementById('metodePembayaran').value;
    let bayar = checkoutTotalAmount;
    let kembalian = 0;
    
    if (metode === 'cash') {
        bayar = parseFloat(document.getElementById('inputBayar').value) || 0;
        
        if (bayar < checkoutTotalAmount) {
            showToast('Jumlah bayar kurang!', true);
            document.getElementById('inputBayar').focus();
            document.getElementById('inputBayar').select();
            return;
        }
        
        kembalian = bayar - checkoutTotalAmount;
    } else {
        // QRIS - stop timer
        if (qrisTimerInterval) {
            clearInterval(qrisTimerInterval);
        }
    }

    const pelangganId = document.getElementById('selectPelanggan')?.value || '';
    
    // Show loading
    const btnProses = document.getElementById('btnProses');
    const originalText = btnProses.textContent;
    btnProses.disabled = true;
    btnProses.textContent = '⏳ Memproses...';
    
    try {
        // Proses ke server
        const res = await api('checkout', {
            pelanggan_id: pelangganId,
            total: checkoutTotalAmount,
            cart: JSON.stringify(cart),
            metode_pembayaran: metode,
            jumlah_bayar: bayar,
            kembalian: kembalian
        });

        if (res.success) {
            hideModal('modalKonfirmasi');
            
            // Simpan data untuk nota
            const pelangganNama = pelangganId 
                ? pelangganList.find(p => p.pelanggan_id == pelangganId)?.nama_pelanggan 
                : 'Umum';

            window.lastTransactionData = {
                id: res.penjualan_id,
                tanggal: new Date().toLocaleString('id-ID', { 
                    day: '2-digit', 
                    month: '2-digit', 
                    year: 'numeric',
                    hour: '2-digit',
                    minute: '2-digit',
                    second: '2-digit'
                }),
                pelanggan: pelangganNama,
                metode: metode === 'qris' ? 'QRIS' : 'Cash',
                items: JSON.parse(JSON.stringify(cart)),
                total: checkoutTotalAmount,
                bayar: bayar,
                kembalian: kembalian
            };

            // Reset
            cart = [];
            renderCart();
            document.getElementById('selectPelanggan').value = '';
            loadProduk();
            loadPenjualan();
            
            // Show nota
            setTimeout(() => {
                showNota();
                showToast('✅ Transaksi berhasil!');
            }, 300);
        } else {
            showToast(res.message || 'Checkout gagal!', true);
            btnProses.disabled = false;
            btnProses.textContent = originalText;
        }
    } catch (error) {
        console.error('Checkout error:', error);
        showToast('Terjadi kesalahan saat checkout', true);
        btnProses.disabled = false;
        btnProses.textContent = originalText;
    }
}

function showNota() {
    if (!window.lastTransactionData) return;
    
    const data = window.lastTransactionData;
    
    document.getElementById('notaId').textContent = data.id;
    document.getElementById('notaTanggal').textContent = data.tanggal;
    document.getElementById('notaPelanggan').textContent = data.pelanggan;
    document.getElementById('notaMetodeLabel').textContent = `Bayar (${data.metode})`;
    
    // Render items (receipt style)
    const itemsContainer = document.getElementById('notaItems');
    itemsContainer.innerHTML = data.items.map(item => `
        <div class="receipt-item">
            <div class="receipt-item-name">${escapeHtml(item.nama_produk)}</div>
            <div class="receipt-item-detail">
                <span>${item.jumlah} x ${formatRupiah(item.harga)}</span>
                <span>${formatRupiah(item.subtotal)}</span>
            </div>
        </div>
    `).join('');
    
    document.getElementById('notaSubtotal').textContent = formatRupiah(data.total);
    document.getElementById('notaTotal').textContent = formatRupiah(data.total);
    document.getElementById('notaBayar').textContent = formatRupiah(data.bayar);
    
    // Hide kembalian for QRIS
    const kembalianRow = document.getElementById('notaKembalianRow');
    if (data.metode === 'QRIS') {
        kembalianRow.style.display = 'none';
    } else {
        kembalianRow.style.display = 'flex';
        document.getElementById('notaKembalian').textContent = formatRupiah(data.kembalian);
        
        // Highlight kembalian jika ada
        if (data.kembalian > 0) {
            document.getElementById('notaKembalian').style.fontWeight = '700';
            document.getElementById('notaKembalian').style.color = '#10b981';
        } else {
            document.getElementById('notaKembalian').style.fontWeight = '400';
            document.getElementById('notaKembalian').style.color = 'inherit';
        }
    }
    
    // Update button selesai untuk history view
    const btnSelesai = document.querySelector('#modalNota .btn-primary');
    if (btnSelesai) {
        btnSelesai.textContent = '✓ Tutup';
    }
    
    showModal('modalNota');
}

function printNota() {
    window.print();
}

function selesaiNota() {
    hideModal('modalNota');
    window.lastTransactionData = null;
}

/* Logout */
async function handleLogout() {
    if (!confirm('Yakin ingin logout?')) return;
    const res = await api('logout');
    if (res.success) window.location.href = 'login.php';
}

/* Riwayat */
async function loadPenjualan() {
    const res = await api('get_penjualan');
    if (res.success) {
        const tbody = document.getElementById('riwayatTable');
        if (!tbody) return;
        
        if (res.data.length === 0) {
            tbody.innerHTML = '<tr><td colspan="6" style="text-align: center; padding: 2rem; color: #64748b;">Belum ada transaksi</td></tr>';
            return;
        }
        
        tbody.innerHTML = res.data.map(p => {
            const badge = p.metode_pembayaran === 'qris' 
                ? '<span class="badge" style="background: #f59e0b; color: white;">📱 QRIS</span>' 
                : '<span class="badge badge-success">💵 Cash</span>';
            
            return `
            <tr>
                <td><strong>#${p.penjualan_id}</strong></td>
                <td>${formatDateTime(p.tanggal_penjualan)}</td>
                <td>${escapeHtml(p.nama_pelanggan || 'Umum')}</td>
                <td class="text-center">${badge}</td>
                <td class="text-right"><strong style="color: #3b82f6;">${formatRupiah(p.total_harga)}</strong></td>
                <td class="text-center">
                    <button class="btn btn-edit btn-sm" onclick="showDetail(${p.penjualan_id})" title="Lihat Nota">
                        🧾 Nota
                    </button>
                </td>
            </tr>
        `}).join('');
    } else {
        const tbody = document.getElementById('riwayatTable');
        if (tbody) {
            tbody.innerHTML = '<tr><td colspan="6" style="text-align: center; padding: 2rem; color: #ef4444;">Gagal memuat data riwayat</td></tr>';
        }
    }
}

async function showDetail(id) {
    const res = await api('get_detail_penjualan', { penjualan_id: id });
    if (res.success && res.data.length > 0) {
        // Get penjualan info
        const resPenjualan = await api('get_penjualan');
        if (!resPenjualan.success) {
            showToast('Gagal memuat data penjualan', true);
            return;
        }
        
        const penjualan = resPenjualan.data.find(p => p.penjualan_id == id);
        if (!penjualan) {
            showToast('Data penjualan tidak ditemukan', true);
            return;
        }
        
        // Calculate kembalian for cash
        let kembalian = 0;
        if (penjualan.metode_pembayaran === 'cash') {
            // Untuk transaksi lama yang tidak punya data bayar, anggap pas
            kembalian = 0;
        }
        
        // Prepare data for nota
        window.lastTransactionData = {
            id: penjualan.penjualan_id,
            tanggal: formatDateTime(penjualan.tanggal_penjualan),
            pelanggan: penjualan.nama_pelanggan || 'Umum',
            metode: penjualan.metode_pembayaran === 'qris' ? 'QRIS' : 'Cash',
            items: res.data.map(d => ({
                nama_produk: d.nama_produk,
                jumlah: d.jumlah_produk,
                harga: parseFloat(d.subtotal) / parseInt(d.jumlah_produk), // Hitung harga satuan
                subtotal: parseFloat(d.subtotal)
            })),
            total: parseFloat(penjualan.total_harga),
            bayar: parseFloat(penjualan.total_harga), // Default bayar = total
            kembalian: kembalian
        };
        
        // Show nota
        showDetailNota();
    } else {
        showToast('Data detail tidak ditemukan', true);
    }
}

function showDetailNota() {
    if (!window.lastTransactionData) return;
    
    const data = window.lastTransactionData;
    
    document.getElementById('notaId').textContent = data.id;
    document.getElementById('notaTanggal').textContent = data.tanggal;
    document.getElementById('notaPelanggan').textContent = data.pelanggan;
    document.getElementById('notaMetodeLabel').textContent = `Bayar (${data.metode})`;
    
    // Render items (receipt style)
    const itemsContainer = document.getElementById('notaItems');
    itemsContainer.innerHTML = data.items.map(item => `
        <div class="receipt-item">
            <div class="receipt-item-name">${escapeHtml(item.nama_produk)}</div>
            <div class="receipt-item-detail">
                <span>${item.jumlah} x ${formatRupiah(item.harga)}</span>
                <span>${formatRupiah(item.subtotal)}</span>
            </div>
        </div>
    `).join('');
    
    document.getElementById('notaSubtotal').textContent = formatRupiah(data.total);
    document.getElementById('notaTotal').textContent = formatRupiah(data.total);
    document.getElementById('notaBayar').textContent = formatRupiah(data.bayar);
    
    // Hide kembalian for QRIS
    const kembalianRow = document.getElementById('notaKembalianRow');
    if (data.metode === 'QRIS') {
        kembalianRow.style.display = 'none';
    } else {
        kembalianRow.style.display = 'flex';
        document.getElementById('notaKembalian').textContent = formatRupiah(data.kembalian);
        
        // Highlight kembalian jika ada
        const kembalianEl = document.getElementById('notaKembalian');
        if (data.kembalian > 0) {
            kembalianEl.style.fontWeight = '700';
            kembalianEl.style.color = '#10b981';
        } else {
            kembalianEl.style.fontWeight = '400';
            kembalianEl.style.color = 'inherit';
        }
    }
    
    // Update button selesai untuk history view
    const btnSelesai = document.querySelector('#modalNota .btn-primary');
    if (btnSelesai) {
        btnSelesai.textContent = '✓ Tutup';
    }
    
    showModal('modalNota');
}

/* Helper Functions */
function escapeHtml(text) {
    if (!text) return '';
    const map = {
        '&': '&amp;',
        '<': '&lt;',
        '>': '&gt;',
        '"': '&quot;',
        "'": '&#039;'
    };
    return text.toString().replace(/[&<>"']/g, m => map[m]);
}

function formatRupiah(angka) {
    if (!angka && angka !== 0) return 'Rp 0';
    const number = parseFloat(angka);
    if (isNaN(number)) return 'Rp 0';
    return 'Rp ' + number.toLocaleString('id-ID', { 
        minimumFractionDigits: 0,
        maximumFractionDigits: 0 
    });
}

function formatDateTime(datetime) {
    if (!datetime) return '-';
    const date = new Date(datetime);
    if (isNaN(date)) return datetime;
    
    return date.toLocaleString('id-ID', {
        day: '2-digit',
        month: '2-digit',
        year: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
    });
}

/* Modal Functions */
function showModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) {
        modal.classList.add('show');
        document.body.style.overflow = 'hidden';
    }
}

function hideModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) {
        modal.classList.remove('show');
        document.body.style.overflow = '';
    }
}

/* Toast Notification */
function showToast(message, isError = false) {
    // Remove existing toast
    const existingToast = document.querySelector('.toast');
    if (existingToast) {
        existingToast.remove();
    }
    
    // Create new toast
    const toast = document.createElement('div');
    toast.className = 'toast' + (isError ? ' error' : '');
    toast.textContent = message;
    
    document.body.appendChild(toast);
    
    // Show toast
    setTimeout(() => {
        toast.classList.add('show');
    }, 10);
    
    // Hide and remove toast
    setTimeout(() => {
        toast.classList.remove('show');
        setTimeout(() => {
            toast.remove();
        }, 300);
    }, 3000);
}

/* Search Functions */
function searchProduk() {
    renderProdukGrid();
}

/* Modal Reset */
function resetModalProduk() {
    document.getElementById('formProduk').reset();
    document.getElementById('produkId').value = '';
    document.getElementById('modalProdukTitle').textContent = 'Tambah Produk';
}

function resetModalPelanggan() {
    document.getElementById('formPelanggan').reset();
    document.getElementById('pelangganId').value = '';
    document.getElementById('modalPelangganTitle').textContent = 'Tambah Pelanggan';
}

/* Click outside modal to close */
document.addEventListener('click', function(e) {
    if (e.target.classList.contains('modal')) {
        const modalId = e.target.id;
        hideModal(modalId);
    }
});

/* ESC key to close modal */
document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape') {
        const openModal = document.querySelector('.modal.show');
        if (openModal) {
            hideModal(openModal.id);
        }
    }
});

/* Enter key untuk input bayar */
document.addEventListener('DOMContentLoaded', function() {
    const inputBayar = document.getElementById('inputBayar');
    if (inputBayar) {
        inputBayar.addEventListener('keypress', function(e) {
            if (e.key === 'Enter') {
                e.preventDefault();
                const btnProses = document.getElementById('btnProses');
                if (btnProses && !btnProses.disabled) {
                    prosesCheckout();
                }
            }
        });
    }
});