<?php
session_start();
require_once 'auth_check.php';
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - UMKM POS</title>
    <link rel="stylesheet" href="assets/style.css">
</head>
<body>
    <!-- Header - SAMA dengan index.php -->
    <header class="header">
        <div class="header-content">
            <div class="logo">🏪 UMKM POS</div>
            
            <nav class="nav">
                <button class="nav-btn active" onclick="window.location.href='dashboard.php'">📊 Dashboard</button>
                <button class="nav-btn" onclick="window.location.href='index.php#kasir'">🛒 Kasir</button>
                <button class="nav-btn" onclick="window.location.href='index.php#produk'">📦 Produk</button>
                <button class="nav-btn" onclick="window.location.href='index.php#pelanggan'">👥 Pelanggan</button>
                <button class="nav-btn" onclick="window.location.href='index.php#riwayat'">📋 Riwayat</button>
                <button class="logout-btn" onclick="handleLogout()">Logout</button>
            </nav>
           <div class="user-info">
                <span class="user-icon">👤</span>
                <span class="user-name"><?php echo htmlspecialchars($_SESSION['admin_nama']); ?></span>
            </div>
        </div>
    </header>
    <!-- Main Content -->
    <main class="main">
        <!-- Statistics Cards -->
        <div class="dashboard-grid">
            <div class="stat-card">
                <div class="stat-icon">💰</div>
                <div class="stat-label">Penjualan Hari Ini</div>
                <div class="stat-value" id="todaySales">Rp 0</div>
            </div>
            
            <div class="stat-card">
                <div class="stat-icon">📅</div>
                <div class="stat-label">Penjualan Bulan Ini</div>
                <div class="stat-value" id="monthSales">Rp 0</div>
            </div>
            
            <div class="stat-card">
                <div class="stat-icon">🧾</div>
                <div class="stat-label">Total Transaksi</div>
                <div class="stat-value" id="totalTransactions">0</div>
            </div>
            
            <div class="stat-card">
                <div class="stat-icon">📦</div>
                <div class="stat-label">Total Produk</div>
                <div class="stat-value" id="totalProducts">0</div>
            </div>
        </div>

        <!-- Charts Grid -->
        <div class="charts-grid">
            <!-- Sales Chart -->
            <div class="chart-container">
                <div class="chart-header">
                    <div>
                        <div class="chart-title">
                            <span class="chart-icon">📈</span>
                            Grafik Penjualan 7 Hari Terakhir
                        </div>
                        <div class="chart-subtitle">Pendapatan harian</div>
                    </div>
                </div>
                <div class="chart-wrapper">
                    <div class="chart-canvas" id="salesChart">
                        <div class="empty-state">
                            <div class="empty-state-icon">📊</div>
                            <div class="empty-state-text">Memuat data...</div>
                        </div>
                    </div>
                </div>
                <div class="chart-stats">
                    <div class="chart-stat-item">
                        <div class="chart-stat-label">Total 7 Hari</div>
                        <div class="chart-stat-value" id="total7Days">Rp 0</div>
                    </div>
                    <div class="chart-stat-item">
                        <div class="chart-stat-label">Rata-rata/Hari</div>
                        <div class="chart-stat-value" id="avgPerDay">Rp 0</div>
                    </div>
                    <div class="chart-stat-item">
                        <div class="chart-stat-label">Hari Tertinggi</div>
                        <div class="chart-stat-value warning" id="highestDay">-</div>
                    </div>
                </div>
            </div>

            <!-- Top Products Chart -->
            <div class="chart-container">
                <div class="chart-header">
                    <div>
                        <div class="chart-title">
                            <span class="chart-icon">🏆</span>
                            Produk Terlaris
                        </div>
                        <div class="chart-subtitle">Top 10 produk paling laku</div>
                    </div>
                </div>
                <div class="chart-wrapper">
                    <div class="chart-canvas" id="topProductsChart">
                        <div class="empty-state">
                            <div class="empty-state-icon">📦</div>
                            <div class="empty-state-text">Memuat data...</div>
                        </div>
                    </div>
                </div>
                <div class="chart-stats">
                    <div class="chart-stat-item">
                        <div class="chart-stat-label">Total Terjual</div>
                        <div class="chart-stat-value warning" id="totalSold">0</div>
                    </div>
                    <div class="chart-stat-item">
                        <div class="chart-stat-label">Total Pendapatan</div>
                        <div class="chart-stat-value" id="totalRevenue">Rp 0</div>
                    </div>
                    <div class="chart-stat-item">
                        <div class="chart-stat-label">Produk Terlaris</div>
                        <div class="chart-stat-value warning" id="topProduct">-</div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Recent Transactions -->
        <div class="recent-transactions">
            <div class="chart-header">
                <div>
                    <div class="chart-title">
                        <span class="chart-icon">🧾</span>
                        Transaksi Terbaru
                    </div>
                    <div class="chart-subtitle">10 transaksi terakhir</div>
                </div>
            </div>
            <div class="transactions-list" id="recentTransactionsList">
                <div class="empty-state">
                    <div class="empty-state-icon">💳</div>
                    <div class="empty-state-text">Memuat data...</div>
                </div>
            </div>
        </div>
    </main>

    <!-- Toast -->
    <div class="toast" id="toast"></div>

    <script src="assets/app.js"></script>
    <script>
        // Load dashboard data
        async function loadDashboardData() {
            try {
                const formData = new FormData();
                formData.append('action', 'get_dashboard_stats');
                
                const res = await fetch('api.php', { method: 'POST', body: formData });
                const data = await res.json();
                
                if (data.success) {
                    // Update statistics
                    document.getElementById('todaySales').textContent = formatRupiah(data.stats.today);
                    document.getElementById('monthSales').textContent = formatRupiah(data.stats.month);
                    document.getElementById('totalTransactions').textContent = data.stats.transactions.toLocaleString();
                    document.getElementById('totalProducts').textContent = data.stats.products.toLocaleString();
                    
                    // Render sales chart
                    renderSalesChart(data.chart);
                    
                    // Render top products chart (LINE CHART)
                    renderTopProductsChart(data.topProducts);
                    
                    // Render recent transactions
                    renderRecentTransactions(data.recentTransactions);
                } else {
                    showToast('Gagal memuat data dashboard: ' + (data.message || 'Unknown error'), true);
                }
            } catch (error) {
                console.error('Load dashboard error:', error);
                showToast('Gagal memuat data dashboard', true);
            }
        }

        function renderSalesChart(chartData) {
            const container = document.getElementById('salesChart');
            if (!chartData || chartData.length === 0) {
                container.innerHTML = `
                    <div class="empty-state">
                        <div class="empty-state-icon">📊</div>
                        <div class="empty-state-text">Belum ada data penjualan</div>
                    </div>
                `;
                return;
            }
            
            // Find max value for scaling
            const maxValue = Math.max(...chartData.map(d => d.total));
            const total = chartData.reduce((sum, d) => sum + d.total, 0);
            const avg = total / chartData.length;
            const highest = chartData.reduce((max, d) => d.total > max.total ? d : max);
            
            // Update stats
            document.getElementById('total7Days').textContent = formatRupiah(total);
            document.getElementById('avgPerDay').textContent = formatRupiah(avg);
            document.getElementById('highestDay').textContent = highest.date;
            
            // Create SVG
            const svgNS = "http://www.w3.org/2000/svg";
            const svg = document.createElementNS(svgNS, "svg");
            svg.setAttribute('viewBox', '0 0 100 100');
            svg.setAttribute('preserveAspectRatio', 'none');
            svg.style.position = 'absolute';
            svg.style.top = '0';
            svg.style.left = '0';
            svg.style.width = '100%';
            svg.style.height = '100%';
            svg.style.pointerEvents = 'none';
            svg.style.zIndex = '1';
            
            // Create path data
            let pathData = '';
            let html = '';
            
            chartData.forEach((point, index) => {
                const heightPercent = maxValue > 0 ? (point.total / maxValue) * 85 : 5;
                const leftPercent = (index / (chartData.length - 1)) * 100;
                const yPos = 100 - heightPercent;
                
                // Build path
                if (index === 0) {
                    pathData = `M ${leftPercent} ${yPos}`;
                } else {
                    pathData += ` L ${leftPercent} ${yPos}`;
                }
                
                html += `
                    <div class="chart-point" style="height: ${heightPercent}%; left: ${leftPercent}%;">
                        <div class="point">
                            <div class="point-value">${formatRupiah(point.total)}</div>
                        </div>
                        <div class="point-label" title="${point.date}">${point.date}</div>
                    </div>
                `;
            });
            
            // Create line path
            const path = document.createElementNS(svgNS, "path");
            path.setAttribute("d", pathData);
            path.setAttribute("fill", "none");
            path.setAttribute("stroke", "#3b82f6");
            path.setAttribute("stroke-width", "0.5");
            path.setAttribute("stroke-linecap", "round");
            path.setAttribute("stroke-linejoin", "round");
            path.style.filter = 'drop-shadow(0 0 4px rgba(59, 130, 246, 0.6))';
            
            svg.appendChild(path);
            
            container.innerHTML = html;
            container.appendChild(svg);
        }

        function renderTopProductsChart(products) {
            const container = document.getElementById('topProductsChart');
            
            if (!products || products.length === 0) {
                container.innerHTML = `
                    <div class="empty-state">
                        <div class="empty-state-icon">📦</div>
                        <div class="empty-state-text">Belum ada data penjualan</div>
                    </div>
                `;
                return;
            }
            
            // Calculate stats
            const totalSold = products.reduce((sum, p) => sum + parseInt(p.total_terjual), 0);
            const totalRevenue = products.reduce((sum, p) => sum + parseFloat(p.total_pendapatan), 0);
            const topProduct = products[0].nama_produk;
            
            // Update stats
            document.getElementById('totalSold').textContent = totalSold.toLocaleString();
            document.getElementById('totalRevenue').textContent = formatRupiah(totalRevenue);
            document.getElementById('topProduct').textContent = topProduct;
            
            // Find max value for scaling
            const maxValue = Math.max(...products.map(p => p.total_terjual));
            
            // Create SVG
            const svgNS = "http://www.w3.org/2000/svg";
            const svg = document.createElementNS(svgNS, "svg");
            svg.setAttribute('viewBox', '0 0 100 100');
            svg.setAttribute('preserveAspectRatio', 'none');
            svg.style.position = 'absolute';
            svg.style.top = '0';
            svg.style.left = '0';
            svg.style.width = '100%';
            svg.style.height = '100%';
            svg.style.pointerEvents = 'none';
            svg.style.zIndex = '1';
            
            // Create path data
            let pathData = '';
            let html = '';
            
            products.forEach((product, index) => {
                const heightPercent = maxValue > 0 ? (product.total_terjual / maxValue) * 85 : 5;
                const leftPercent = (index / (products.length - 1)) * 100;
                const yPos = 100 - heightPercent;
                const emoji = getProductEmoji(product.nama_produk);
                const truncatedName = product.nama_produk.length > 10
                    ? product.nama_produk.substring(0, 10) + '...'
                    : product.nama_produk;
                
                // Build path
                if (index === 0) {
                    pathData = `M ${leftPercent} ${yPos}`;
                } else {
                    pathData += ` L ${leftPercent} ${yPos}`;
                }
                
                html += `
                    <div class="chart-point" style="height: ${heightPercent}%; left: ${leftPercent}%;">
                        <div class="point product-point">
                            <div class="point-value">
                                ${emoji} ${product.total_terjual} terjual
                                <small>${formatRupiah(product.total_pendapatan)}</small>
                            </div>
                        </div>
                        <div class="point-label" title="${product.nama_produk}">${truncatedName}</div>
                    </div>
                `;
            });
            
            // Create line path
            const path = document.createElementNS(svgNS, "path");
            path.setAttribute("d", pathData);
            path.setAttribute("fill", "none");
            path.setAttribute("stroke", "#f59e0b");
            path.setAttribute("stroke-width", "0.5");
            path.setAttribute("stroke-linecap", "round");
            path.setAttribute("stroke-linejoin", "round");
            path.style.filter = 'drop-shadow(0 0 4px rgba(245, 158, 11, 0.6))';
            
            svg.appendChild(path);
            
            container.innerHTML = html;
            container.appendChild(svg);
        }

        function getProductEmoji(namaProduk) {
            const nama = namaProduk.toLowerCase();
            
            // Makanan
            if (nama.includes('nasi') || nama.includes('rice')) return '🍚';
            if (nama.includes('mie') || nama.includes('noodle')) return '🍜';
            if (nama.includes('ayam') || nama.includes('chicken')) return '🍗';
            if (nama.includes('sate') || nama.includes('satay')) return '🍢';
            if (nama.includes('burger')) return '🍔';
            if (nama.includes('pizza')) return '🍕';
            if (nama.includes('roti') || nama.includes('bread')) return '🍞';
            
            // Minuman
            if (nama.includes('kopi') || nama.includes('coffee')) return '☕';
            if (nama.includes('teh') || nama.includes('tea')) return '🍵';
            if (nama.includes('jus') || nama.includes('juice')) return '🧃';
            if (nama.includes('susu') || nama.includes('milk')) return '🥛';
            if (nama.includes('es krim') || nama.includes('ice cream')) return '🍦';
            if (nama.includes('smoothie')) return '🥤';
            
            // Snack
            if (nama.includes('kentang') || nama.includes('potato') || nama.includes('fries')) return '🍟';
            if (nama.includes('donat') || nama.includes('donut')) return '🍩';
            if (nama.includes('kue') || nama.includes('cake')) return '🍰';
            if (nama.includes('cookie') || nama.includes('biskuit')) return '🍪';
            
            // Default
            return '📦';
        }

        function renderRecentTransactions(transactions) {
            const container = document.getElementById('recentTransactionsList');
            
            if (!transactions || transactions.length === 0) {
                container.innerHTML = `
                    <div class="empty-state">
                        <div class="empty-state-icon">💳</div>
                        <div class="empty-state-text">Belum ada transaksi</div>
                    </div>
                `;
                return;
            }
            
            container.innerHTML = transactions.map(trans => {
                const date = new Date(trans.tanggal_penjualan);
                const formattedDate = date.toLocaleDateString('id-ID', { day: '2-digit', month: 'short', year: 'numeric' });
                const formattedTime = date.toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' });
                
                const badgeClass = trans.metode_pembayaran === 'qris' ? 'badge-warning' : 'badge-success';
                const badgeText = trans.metode_pembayaran === 'qris' ? 'QRIS' : 'CASH';
                
                return `
                    <div class="transaction-item">
                        <div class="transaction-id">#${trans.penjualan_id}</div>
                        <div class="transaction-content">
                            <div class="transaction-header">
                                <div class="transaction-customer">${escapeHtml(trans.nama_pelanggan)}</div>
                                <span class="badge ${badgeClass}">${badgeText}</span>
                            </div>
                            <div class="transaction-footer">
                                <div class="transaction-time">
                                    <span class="icon">🕐</span>
                                    ${formattedDate} ${formattedTime}
                                </div>
                                <div class="transaction-amount">${formatRupiah(trans.total_harga)}</div>
                            </div>
                        </div>
                    </div>
                `;
            }).join('');
        }

        // Helper functions
        function formatRupiah(num) {
            return 'Rp ' + Number(num).toLocaleString('id-ID');
        }

        function escapeHtml(s) {
            if (s === null || s === undefined) return '';
            return String(s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]);
        }

        function showToast(msg, isError = false) {
            const t = document.getElementById('toast');
            if (!t) return;
            t.textContent = msg;
            t.className = 'toast show' + (isError ? ' error' : '');
            setTimeout(() => t.className = 'toast', 3000);
        }

        async function handleLogout() {
            if (!confirm('Yakin ingin logout?')) return;
            
            const formData = new FormData();
            formData.append('action', 'logout');
            
            try {
                const res = await fetch('api.php', { method: 'POST', body: formData });
                const data = await res.json();
                
                if (data.success) {
                    window.location.href = 'login.php';
                } else {
                    showToast('Logout gagal', true);
                }
            } catch (error) {
                console.error('Logout error:', error);
                showToast('Terjadi kesalahan saat logout', true);
            }
        }

        // Load data on page load
        document.addEventListener('DOMContentLoaded', () => {
            loadDashboardData();
            
            // Refresh setiap 30 detik
            setInterval(loadDashboardData, 30000);
        });
    </script>
</body>
</html>