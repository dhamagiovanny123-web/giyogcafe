<?php
// Set timezone ke WIB (Jakarta)
date_default_timezone_set('Asia/Jakarta');

// Error reporting
error_reporting(E_ALL);
ini_set('display_errors', 0);
ini_set('log_errors', 1);
ini_set('error_log', __DIR__ . '/error.log');

// Konfigurasi database
$db_config = [
    'host' => '127.0.0.1',
    'user' => 'root',
    'pass' => '',
    'name' => 'db_kasir_giyogcafe', // Atau 'db_kasir_giyogcafe' sesuai yang Anda mau
    'port' => 3307,
];

// Cek mysqli extension
if (!extension_loaded('mysqli')) {
    $error_msg = 'MySQLi extension tidak tersedia';
    error_log($error_msg);
    
    if (basename($_SERVER['PHP_SELF']) === 'api.php') {
        header('Content-Type: application/json');
        die(json_encode(['success' => false, 'message' => $error_msg]));
    }
    die('<h1>Server Error</h1><p>' . $error_msg . '</p>');
}

// Matikan error reporting mysqli
mysqli_report(MYSQLI_REPORT_OFF);

try {
    // Coba koneksi dengan berbagai port
    $ports = [$db_config['port'], 3307, 3306, 3308];
    $connected = false;
    $last_error = '';
    $working_port = null;
    
    foreach ($ports as $port) {
        $conn = @new mysqli(
            $db_config['host'], 
            $db_config['user'], 
            $db_config['pass'], 
            '',
            $port
        );
        
        if (!$conn->connect_error) {
            $connected = true;
            $working_port = $port;
            error_log("MySQL connected on port: $port");
            break;
        }
        $last_error = $conn->connect_error;
    }
    
    if (!$connected) {
        throw new Exception("MySQL tidak running! Error: $last_error");
    }
    
    // Cek apakah database sudah ada
    $db_exists = $conn->select_db($db_config['name']);
    
    if (!$db_exists) {
        // Database belum ada, buat baru
        $create_db = $conn->query("CREATE DATABASE `{$db_config['name']}` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
        
        if (!$create_db) {
            throw new Exception("Gagal membuat database: " . $conn->error);
        }
        
        $conn->select_db($db_config['name']);
        error_log("Database '{$db_config['name']}' berhasil dibuat");
        
        // Import struktur dari file SQL
        $sql_file = __DIR__ . '/umkm_pos.sql';
        if (file_exists($sql_file)) {
            $sql_content = file_get_contents($sql_file);
            
            if ($sql_content) {
                // Remove comments and split by semicolon
                $sql_content = preg_replace('/^--.*$/m', '', $sql_content);
                $sql_content = preg_replace('/\/\*.*?\*\//s', '', $sql_content);
                
                $queries = array_filter(
                    array_map('trim', explode(';', $sql_content)),
                    function($query) {
                        return !empty($query) && 
                               strlen($query) > 5 && 
                               stripos($query, 'SET') !== 0 &&
                               stripos($query, 'START TRANSACTION') !== 0 &&
                               stripos($query, 'COMMIT') !== 0;
                    }
                );
                
                foreach ($queries as $query) {
                    if (!empty($query)) {
                        $result = $conn->query($query);
                        if (!$result) {
                            error_log("Query error: " . $conn->error . "\nQuery: " . substr($query, 0, 100));
                        }
                    }
                }
                
                error_log("Database structure imported from SQL file");
            }
        } else {
            error_log("SQL file not found: $sql_file");
        }
    } else {
        // Database sudah ada, cek tabel
        $tables_result = $conn->query("SHOW TABLES");
        $table_count = $tables_result ? $tables_result->num_rows : 0;
        
        if ($table_count == 0) {
            // Database kosong, import struktur
            $sql_file = __DIR__ . '/umkm_pos.sql';
            if (file_exists($sql_file)) {
                $sql_content = file_get_contents($sql_file);
                
                if ($sql_content) {
                    $sql_content = preg_replace('/^--.*$/m', '', $sql_content);
                    $sql_content = preg_replace('/\/\*.*?\*\//s', '', $sql_content);
                    
                    $queries = array_filter(
                        array_map('trim', explode(';', $sql_content)),
                        function($query) {
                            return !empty($query) && 
                                   strlen($query) > 5 && 
                                   stripos($query, 'SET') !== 0 &&
                                   stripos($query, 'START TRANSACTION') !== 0 &&
                                   stripos($query, 'COMMIT') !== 0;
                        }
                    );
                    
                    foreach ($queries as $query) {
                        if (!empty($query)) {
                            $conn->query($query);
                        }
                    }
                    
                    error_log("Tables imported to existing database");
                }
            }
        } else {
            error_log("Database '{$db_config['name']}' exists with $table_count tables");
        }
    }
    
    // Set timezone dan charset
    $conn->query("SET time_zone = '+07:00'");
    $conn->set_charset("utf8mb4");
    
} catch (Exception $e) {
    $error_msg = $e->getMessage();
    error_log("Database Error: " . $error_msg);
    
    if (basename($_SERVER['PHP_SELF']) === 'api.php') {
        header('Content-Type: application/json');
        die(json_encode([
            'success' => false, 
            'message' => 'Database connection failed',
            'error' => $error_msg
        ]));
    }
    
    die('
<!DOCTYPE html>
<html>
<head>
    <title>Database Error</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: Arial, sans-serif; background: #f5f5f5; padding: 50px; }
        .error-box { background: white; padding: 40px; border-radius: 10px; box-shadow: 0 2px 20px rgba(0,0,0,0.1); max-width: 700px; margin: 0 auto; }
        h1 { color: #ef4444; margin-bottom: 20px; }
        .error-msg { background: #fee2e2; padding: 15px; border-radius: 5px; border-left: 4px solid #ef4444; margin: 20px 0; font-family: monospace; word-break: break-all; }
        .steps { background: #dbeafe; padding: 20px; border-radius: 5px; margin: 20px 0; }
        .steps h3 { color: #1e40af; margin-bottom: 10px; }
        .steps ol { margin-left: 20px; }
        .steps li { margin: 10px 0; line-height: 1.6; }
        code { background: #f3f4f6; padding: 3px 8px; border-radius: 3px; font-family: monospace; }
        .btn { display: inline-block; padding: 12px 24px; background: #3b82f6; color: white; text-decoration: none; border-radius: 5px; margin: 10px 5px; }
        .btn:hover { background: #2563eb; }
        .warning { background: #fef3c7; border-left: 4px solid #f59e0b; padding: 15px; margin: 20px 0; }
    </style>
</head>
<body>
    <div class="error-box">
        <h1>❌ Database Connection Error</h1>
        
        <div class="error-msg">' . htmlspecialchars($error_msg) . '</div>
        
        <div class="warning">
            <strong>⚠️ MySQL tidak bisa diakses!</strong><br>
            Pastikan MySQL di XAMPP sudah running pada port <strong>3307</strong>.
        </div>
        
        <div class="steps">
            <h3>📋 Cara Memperbaiki:</h3>
            <ol>
                <li><strong>Buka XAMPP Control Panel</strong></li>
                <li>Pastikan <strong>MySQL</strong> berwarna <span style="color: green; font-weight: bold;">HIJAU (Running)</span></li>
                <li>Jika belum running, klik tombol <strong>Start</strong> pada MySQL</li>
                <li>Tunggu hingga status berubah menjadi Running</li>
                <li>Refresh halaman ini</li>
            </ol>
        </div>
        
        <div style="text-align: center;">
            <a href="check_mysql.php" class="btn">🔍 Check MySQL</a>
            <a href="' . htmlspecialchars($_SERVER['PHP_SELF']) . '" class="btn" style="background: #10b981;">🔄 Refresh</a>
        </div>
    </div>
</body>
</html>
    ');
}
?>