<?php
session_start();
require_once 'auth_check.php';
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kasir UMKM - Point of Sale</title>
    <link rel="stylesheet" href="assets/style.css">
</head>
<body>
    <!-- Header -->
    <header class="header">
        <div class="header-content">
            <div class="logo">🛒 Giyogcafe</div>
            <nav class="nav">
                <button class="nav-btn" onclick="window.location.href='dashboard.php'">📊 Dashboard</button>
                <button class="nav-btn active" onclick="showTab('kasir', event)">🛒 Kasir</button>
                <button class="nav-btn" onclick="showTab('produk', event)">📦 Produk</button>
                <button class="nav-btn" onclick="showTab('pelanggan', event)">👥 Pelanggan</button>
                <button class="nav-btn" onclick="showTab('riwayat', event)">📋 Riwayat</button>
                <button class="logout-btn" onclick="handleLogout()">Logout</button>
            </nav>
            <div class="user-info">
                <span class="user-icon">👤</span>
                <span class="user-name"><?php echo htmlspecialchars($_SESSION['admin_nama']); ?></span>
            </div>
        </div>
    </header>

    <!-- Main Content -->
    <main class="main">
        <!-- TAB KASIR -->
        <div id="tab-kasir" class="tab-content active">
            <div class="kasir-grid">
                <!-- Produk List -->
                <div class="card">
                    <div class="search-box">
                        <input type="text" id="searchProduk" placeholder="Cari produk..." oninput="renderProdukGrid()">
                    </div>
                    <div class="product-grid" id="produkGrid"></div>
                </div>

                <!-- Cart -->
                <div class="card">
                    <div class="card-title">🧾 Keranjang</div>
                    <select class="select-pelanggan" id="selectPelanggan">
                        <option value="">Pelanggan Umum</option>
                    </select>
                    <div class="cart-items" id="cartItems">
                        <div class="cart-empty">Keranjang kosong</div>
                    </div>
                    <div class="cart-total">
                        <div class="total-row">
                            <span>Total</span>
                            <span class="total-amount" id="totalAmount">Rp 0</span>
                        </div>
                        <button class="checkout-btn" onclick="checkout()" id="checkoutBtn" disabled>Bayar Sekarang</button>
                    </div>
                </div>
            </div>
        </div>

        <!-- TAB PRODUK -->
        <div id="tab-produk" class="tab-content">
            <div class="card">
                <div class="header-actions">
                    <div class="page-title">📦 Manajemen Produk</div>
                    <button class="btn btn-primary" onclick="showModal('modalProduk')">+ Tambah Produk</button>
                </div>
                <div style="overflow-x: auto;">
                    <table class="data-table">
                        <thead>
                            <tr>
                                <th>Nama Produk</th>
                                <th class="text-right">Harga</th>
                                <th class="text-center">Stok</th>
                                <th class="text-center">Aksi</th>
                            </tr>
                        </thead>
                        <tbody id="produkTable"></tbody>
                    </table>
                </div>
            </div>
        </div>

        <!-- TAB PELANGGAN -->
        <div id="tab-pelanggan" class="tab-content">
            <div class="card">
                <div class="header-actions">
                    <div class="page-title">👥 Manajemen Pelanggan VIP</div>
                    <button class="btn btn-primary" onclick="showModal('modalPelanggan')">+ Tambah Pelanggan VIP</button>
                </div>
                <div style="overflow-x: auto;">
                    <table class="data-table">
                        <thead>
                            <tr>
                                <th>Nama</th>
                                <th>Telepon</th>
                                <th>Alamat</th>
                                <th class="text-center">Aksi</th>
                            </tr>
                        </thead>
                        <tbody id="pelangganTable"></tbody>
                    </table>
                </div>
            </div>
        </div>

        <!-- TAB RIWAYAT -->
        <div id="tab-riwayat" class="tab-content">
            <div class="card">
                <div class="page-title" style="margin-bottom: 1rem;">📋 Riwayat Penjualan</div>
                <div style="overflow-x: auto;">
                    <table class="data-table">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Tanggal</th>
                                <th>Pelanggan</th>
                                <th>Metode</th>
                                <th class="text-right">Total</th>
                                <th class="text-center">Detail</th>
                            </tr>
                        </thead>
                        <tbody id="riwayatTable"></tbody>
                    </table>
                </div>
            </div>
        </div>
    </main>

    <!-- Modal Produk -->
    <div class="modal" id="modalProduk">
        <div class="modal-content">
            <div class="modal-header">
                <div class="modal-title" id="modalProdukTitle">Tambah Produk</div>
                <button class="modal-close" onclick="hideModal('modalProduk')">&times;</button>
            </div>
            <form id="formProduk" onsubmit="saveProduk(event)">
                <input type="hidden" id="produkId">
                <div class="form-group">
                    <label>Nama Produk</label>
                    <input type="text" id="namaProduk" required>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label>Harga</label>
                        <input type="number" id="hargaProduk" required min="0">
                    </div>
                    <div class="form-group">
                        <label>Stok</label>
                        <input type="number" id="stokProduk" required min="0">
                    </div>
                </div>
                <button type="submit" class="btn btn-primary" style="width: 100%;">Simpan</button>
            </form>
        </div>
    </div>

    <!-- Modal Pelanggan -->
    <div class="modal" id="modalPelanggan">
        <div class="modal-content">
            <div class="modal-header">
                <div class="modal-title" id="modalPelangganTitle">Tambah Pelanggan VIP</div>
                <button class="modal-close" onclick="hideModal('modalPelanggan')">&times;</button>
            </div>
            <form id="formPelanggan" onsubmit="savePelanggan(event)">
                <input type="hidden" id="pelangganId">
                <div class="form-group">
                    <label>Nama Pelanggan VIP</label>
                    <input type="text" id="namaPelanggan" required>
                </div>
                <div class="form-group">
                    <label>Nomor Telepon</label>
                    <input type="text" id="telpPelanggan">
                </div>
                <div class="form-group">
                    <label>Alamat</label>
                    <textarea id="alamatPelanggan" rows="3"></textarea>
                </div>
                <button type="submit" class="btn btn-primary" style="width: 100%;">Simpan</button>
            </form>
        </div>
    </div>

    <!-- Modal Konfirmasi Checkout -->
    <div class="modal" id="modalKonfirmasi">
        <div class="modal-content" style="max-width: 450px;">
            <div class="modal-header">
                <h2 style="margin: 0; color: #f1f5f9; font-size: 1.5rem;">💰 Pembayaran</h2>
                <button class="modal-close" onclick="hideModal('modalKonfirmasi')">&times;</button>
            </div>
            <div class="modal-body">
                <!-- Total Belanja -->
                <div style="background: linear-gradient(135deg, #3b82f6 0%, #2563eb 100%); padding: 2rem; border-radius: 12px; text-align: center; margin-bottom: 1.5rem;">
                    <div style="color: rgba(255,255,255,0.9); font-size: 0.875rem; margin-bottom: 0.5rem;">Total Belanja</div>
                    <div id="checkoutTotal" style="color: white; font-size: 2.5rem; font-weight: 700;">Rp 0</div>
                </div>

                <!-- Metode Pembayaran -->
                <div style="margin-bottom: 1.5rem;">
                    <label style="color: #94a3b8; font-size: 0.875rem; margin-bottom: 0.5rem; display: block;">Metode Pembayaran</label>
                    <select id="metodePembayaran" class="form-input" onchange="changeMetodePembayaran()" style="width: 100%; padding: 0.75rem; border: 2px solid #334155; border-radius: 8px; background: #0f172a; color: #f1f5f9;">
                        <option value="cash">💵 Cash</option>
                        <option value="qris">📱 QRIS</option>
                    </select>
                </div>

                <!-- QRIS Container -->
                <div id="qrisContainer" style="display: none;">
                    <div style="background: white; padding: 1.5rem; border-radius: 12px; text-align: center; margin-bottom: 1rem;">
                        <div style="color: #1e293b; font-weight: 600; margin-bottom: 1rem; font-size: 1.1rem;">
                            📱 Scan QR Code untuk membayar
                        </div>
                        <div id="qrcode" style="display: flex; justify-content: center; margin-bottom: 1rem;"></div>
                        <div style="display: flex; align-items: center; justify-content: center; gap: 0.5rem; color: #64748b;">
                            <span>⏱️ Waktu tersisa:</span>
                            <span id="qrisTimer" style="font-weight: 700; color: #10b981; font-size: 1.1rem;">5:00</span>
                        </div>
                    </div>
                    <div style="background: #fef3c7; border: 1px solid #fbbf24; padding: 1rem; border-radius: 8px; margin-bottom: 1rem;">
                        <div style="color: #92400e; font-size: 0.875rem; text-align: center;">
                            <strong>⚠️ Petunjuk:</strong><br>
                            1. Buka aplikasi e-wallet Anda<br>
                            2. Scan QR Code di atas<br>
                            3. Konfirmasi pembayaran<br>
                            4. Klik "Konfirmasi Pembayaran QRIS"
                        </div>
                    </div>
                </div>

                <!-- Cash Payment Container -->
                <div id="cashPayment">
                    <!-- Input Bayar -->
                    <div class="form-group" style="margin-bottom: 1rem;">
                        <label style="color: #94a3b8; font-size: 0.875rem; margin-bottom: 0.5rem; display: block;">Jumlah Bayar</label>
                        <input type="number" id="inputBayar" class="form-input" 
                               style="width: 100%; padding: 1rem; font-size: 1.25rem; border: 2px solid #334155; border-radius: 8px; background: #0f172a; color: #f1f5f9;"
                               placeholder="0" oninput="hitungKembalian()">
                    </div>

                    <!-- Kembalian -->
                    <div style="background: #0f172a; padding: 1.5rem; border-radius: 8px; border: 1px solid #334155; margin-bottom: 1.5rem;">
                        <div style="display: flex; justify-content: space-between; align-items: center;">
                            <span style="color: #94a3b8; font-size: 1rem;">Kembalian</span>
                            <span id="kembalianAmount" style="color: #10b981; font-size: 1.5rem; font-weight: 700;">Rp 0</span>
                        </div>
                    </div>

                    <!-- Quick Amount Buttons -->
                    <div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 0.5rem; margin-bottom: 1.5rem;">
                        <button type="button" class="quick-amount-btn" onclick="setQuickAmount(20000)">20K</button>
                        <button type="button" class="quick-amount-btn" onclick="setQuickAmount(50000)">50K</button>
                        <button type="button" class="quick-amount-btn" onclick="setQuickAmount(100000)">100K</button>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button class="btn btn-secondary" onclick="hideModal('modalKonfirmasi')" style="flex: 1;">Batal</button>
                <button class="btn btn-primary" onclick="prosesCheckout()" id="btnProses" style="flex: 2;">✓ Proses Pembayaran</button>
            </div>
        </div>
    </div>

    <!-- Modal Nota (Receipt Style) -->
    <div class="modal" id="modalNota">
        <div class="modal-content receipt-modal">
            <div class="receipt-paper">
                <!-- Header -->
                <div class="receipt-header">
                    <h1>🏪 GIYOGCAFE</h1>
                    <p>Jl. Contoh No. 123</p>
                    <p>Telp: 08123456789</p>
                </div>

                <div class="receipt-divider">- - - - - - - - - - - - - - - - - - - - - -</div>

                <!-- Info Transaksi -->
                <div class="receipt-info">
                    <div class="receipt-row">
                        <span>No</span>
                        <span id="notaId">-</span>
                    </div>
                    <div class="receipt-row">
                        <span>Tanggal</span>
                        <span id="notaTanggal">-</span>
                    </div>
                    <div class="receipt-row">
                        <span>Kasir</span>
                        <span><?php echo htmlspecialchars($_SESSION['admin_nama']); ?></span>
                    </div>
                    <div class="receipt-row">
                        <span>Pelanggan</span>
                        <span id="notaPelanggan">-</span>
                    </div>
                </div>

                <div class="receipt-divider">- - - - - - - - - - - - - - - - - - - - - -</div>

                <!-- Items -->
                <div class="receipt-items" id="notaItems"></div>

                <div class="receipt-divider">- - - - - - - - - - - - - - - - - - - - - -</div>

                <!-- Total -->
                <div class="receipt-total">
                    <div class="receipt-row">
                        <span>Subtotal</span>
                        <span id="notaSubtotal">Rp 0</span>
                    </div>
                    <div class="receipt-row bold">
                        <span>TOTAL</span>
                        <span id="notaTotal">Rp 0</span>
                    </div>
                    <div class="receipt-row">
                        <span id="notaMetodeLabel">Bayar (Cash)</span>
                        <span id="notaBayar">Rp 0</span>
                    </div>
                    <div class="receipt-row" id="notaKembalianRow">
                        <span>Kembalian</span>
                        <span id="notaKembalian">Rp 0</span>
                    </div>
                </div>

                <div class="receipt-divider">- - - - - - - - - - - - - - - - - - - - - -</div>

                <!-- Footer -->
                <div class="receipt-footer">
                    <p>TERIMA KASIH</p>
                    <p>Barang yang sudah dibeli</p>
                    <p>tidak dapat dikembalikan</p>
                </div>
            </div>

            <div class="modal-footer" style="margin-top: 1.5rem;">
                <button class="btn btn-secondary" onclick="printNota()">🖨️ Print</button>
                <button class="btn btn-primary" onclick="selesaiNota()">✓ Selesai</button>
            </div>
        </div>
    </div>

    <!-- Modal Detail Penjualan -->
    <div class="modal" id="modalDetail">
        <div class="modal-content">
            <div class="modal-header">
                <div class="modal-title">Detail Penjualan</div>
                <button class="modal-close" onclick="hideModal('modalDetail')">&times;</button>
            </div>
            <div class="modal-body">
                <table class="data-table">
                    <thead>
                        <tr>
                            <th>Produk</th>
                            <th class="text-center">Qty</th>
                            <th class="text-right">Subtotal</th>
                        </tr>
                    </thead>
                    <tbody id="detailTable"></tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- Toast Notification -->
    <div class="toast" id="toast"></div>

    <!-- Load JavaScript -->
    <script src="assets/app.js"></script>
</body>
</html>
