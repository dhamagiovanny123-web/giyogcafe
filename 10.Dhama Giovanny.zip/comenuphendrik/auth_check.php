<?php
// Cek apakah session sudah aktif
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Jika belum login, redirect ke login
if (!isset($_SESSION['admin_id'])) {
    header('Location: login.php');
    exit;
}
?>