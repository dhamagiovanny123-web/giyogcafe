<?php
session_start();

// Jika sudah login, redirect ke index
if (isset($_SESSION['admin_id'])) {
    header('Location: index.php');
    exit;
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_once 'db.php';
    
    $username = $_POST['username'] ?? '';
    $password = $_POST['password'] ?? '';
    
    if (empty($username) || empty($password)) {
        $error = 'Username dan password harus diisi!';
    } else {
        // Query ke database
        $stmt = $conn->prepare("SELECT * FROM admin WHERE username = ?");
        $stmt->bind_param("s", $username);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows > 0) {
            $admin = $result->fetch_assoc();
            
            // Verifikasi password yang di-hash dengan bcrypt
            if (password_verify($password, $admin['password'])) {
                $_SESSION['admin_id'] = $admin['admin_id'];
                $_SESSION['admin_nama'] = $admin['nama_lengkap']; // nama_lengkap, bukan nama_admin
                $_SESSION['admin_username'] = $admin['username'];
                
                header('Location: index.php');
                exit;
            } else {
                $error = 'Password salah!';
            }
        } else {
            $error = 'Username tidak ditemukan!';
        }
        
        $stmt->close();
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - UMKM POS</title>
    <link rel="stylesheet" href="assets/style.css">
</head>
<body>
    <div class="login-container">
        <div class="login-card">
            <div class="login-header">
                <div class="login-logo">🛒</div>
                <div class="login-title">UMKM POS</div>
                <div class="login-subtitle">Silakan login untuk melanjutkan</div>
            </div>
            <form class="login-form" onsubmit="handleLogin(event)">
                <div class="form-group">
                    <label>Username</label>
                    <input type="text" id="username" name="username" required autofocus maxlength="50">
                </div>
                <div class="form-group">
                    <label>Password</label>
                    <input type="password" id="password" name="password" required maxlength="100">
                </div>
                <button type="submit" class="login-btn">Login</button>
            </form>
            <div class="login-info">
                <strong>Default Login:</strong><br>
                Username: <strong>admin</strong><br>
                Password: <strong>admin123</strong>
            </div>
        </div>
    </div>

    <div class="toast" id="toast"></div>

    <script>
        async function handleLogin(e) {
            e.preventDefault();
            
            const username = document.getElementById('username').value.trim();
            const password = document.getElementById('password').value;

            if (!username || !password) {
                showToast('Username dan password harus diisi', true);
                return;
            }

            const formData = new FormData();
            formData.append('action', 'login');
            formData.append('username', username);
            formData.append('password', password);

            try {
                const res = await fetch('api.php', { method: 'POST', body: formData });
                const data = await res.json();

                showToast(data.message, !data.success);
                
                if (data.success) {
                    setTimeout(() => {
                        window.location.href = 'index.php';
                    }, 500);
                }
            } catch (error) {
                console.error('Login error:', error);
                showToast('Terjadi kesalahan saat login', true);
            }
        }

        function showToast(msg, isError = false) {
            const t = document.getElementById('toast');
            t.textContent = msg;
            t.className = 'toast show' + (isError ? ' error' : '');
            setTimeout(() => t.className = 'toast', 3000);
        }
    </script>
</body>
</html>