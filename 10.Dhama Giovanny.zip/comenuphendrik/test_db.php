<?php
require_once 'db.php';

echo "<!DOCTYPE html><html><head><title>Test Connection</title>";
echo "<style>body{font-family:Arial;padding:20px;background:#f5f5f5;}";
echo ".box{background:white;padding:30px;border-radius:10px;max-width:600px;margin:0 auto;box-shadow:0 2px 10px rgba(0,0,0,0.1);}";
echo ".success{color:#10b981;} .error{color:#ef4444;} .info{background:#dbeafe;padding:15px;margin:10px 0;border-radius:5px;}</style>";
echo "</head><body><div class='box'>";

echo "<h2>🔍 Database Connection Test</h2>";

if (isset($conn) && $conn) {
    echo "<p class='success'>✅ Connected to MySQL successfully!</p>";
    echo "<div class='info'>";
    echo "<strong>Database:</strong> {$db_config['name']}<br>";
    echo "<strong>Port:</strong> " . $conn->port . "<br>";
    echo "<strong>MySQL Version:</strong> " . $conn->server_info . "<br>";
    echo "</div>";
    
    // Cek tabel
    echo "<h3>Tables:</h3><ul>";
    $result = $conn->query("SHOW TABLES");
    if ($result && $result->num_rows > 0) {
        while ($row = $result->fetch_array()) {
            echo "<li>" . htmlspecialchars($row[0]) . "</li>";
        }
        echo "</ul>";
        
        // Cek admin
        $admin = $conn->query("SELECT * FROM admin LIMIT 1");
        if ($admin && $admin->num_rows > 0) {
            echo "<p class='success'>✅ Admin account exists</p>";
            $data = $admin->fetch_assoc();
            echo "<div class='info'>";
            echo "<strong>Username:</strong> " . htmlspecialchars($data['username']) . "<br>";
            echo "<strong>Password:</strong> admin123 (default)<br>";
            echo "</div>";
        }
        
        echo "<br><a href='login.php' style='display:inline-block;padding:12px 24px;background:#3b82f6;color:white;text-decoration:none;border-radius:5px;'>🚀 Go to Login</a>";
    } else {
        echo "</ul><p class='error'>⚠️ No tables found. Database might be empty.</p>";
    }
} else {
    echo "<p class='error'>❌ Connection failed</p>";
}

echo "</div></body></html>";
?>