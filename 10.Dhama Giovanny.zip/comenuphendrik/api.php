<?php
// Cek session dulu sebelum start
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
header('Content-Type: application/json');
require_once __DIR__ . '/db.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !isset($_POST['action'])) {
    echo json_encode(['success' => false, 'message' => 'Invalid request']);
    exit;
}

$action = $_POST['action'] ?? '';
$response = ['success' => false, 'message' => 'Action tidak valid'];

try {
    switch ($action) {
        // === AUTH ===
        case 'login':
            $username = $_POST['username'] ?? '';
            $password = $_POST['password'] ?? '';

            if ($username === '' || $password === '') {
                $response = ['success' => false, 'message' => 'Username dan password harus diisi!'];
                break;
            }

            $stmt = $conn->prepare("SELECT admin_id, username, password, nama_lengkap FROM admin WHERE username = ?");
            if (!$stmt) {
                $response = ['success' => false, 'message' => 'DB error: ' . $conn->error];
                break;
            }
            $stmt->bind_param("s", $username);
            $stmt->execute();
            $result = $stmt->get_result();

            if ($result && $result->num_rows === 1) {
                $admin = $result->fetch_assoc();

                // Cek bcrypt terlebih dulu, fallback plaintext bila DB belum hash
                $isValid = password_verify($password, $admin['password']) || ($password === $admin['password']);

                if ($isValid) {
                    $_SESSION['admin_id'] = (int)$admin['admin_id'];
                    $_SESSION['admin_username'] = $admin['username'];
                    $_SESSION['admin_nama'] = $admin['nama_lengkap'] ?: $admin['username'];

                    $response = ['success' => true, 'message' => 'Login berhasil'];
                } else {
                    $response = ['success' => false, 'message' => 'Password salah!'];
                }
            } else {
                $response = ['success' => false, 'message' => 'Username tidak ditemukan!'];
            }
            $stmt?->close();
            break;

        case 'logout':
            session_destroy();
            $response = ['success' => true, 'message' => 'Logout berhasil'];
            break;

        case 'check_session':
            if (isset($_SESSION['admin_id'])) {
                $response = ['success' => true, 'logged_in' => true, 'nama' => $_SESSION['admin_nama']];
            } else {
                $response = ['success' => true, 'logged_in' => false];
            }
            break;

        // === DASHBOARD STATS ===
        case 'get_dashboard_stats':
            if (!isset($_SESSION['admin_id'])) {
                $response = ['success' => false, 'message' => 'Unauthorized'];
                break;
            }

            // Total penjualan hari ini
            $today = $conn->query("SELECT IFNULL(SUM(total_harga), 0) as total FROM penjualan WHERE DATE(tanggal_penjualan) = CURDATE()")->fetch_assoc();
            
            // Total penjualan bulan ini
            $month = $conn->query("SELECT IFNULL(SUM(total_harga), 0) as total FROM penjualan WHERE MONTH(tanggal_penjualan) = MONTH(CURDATE()) AND YEAR(tanggal_penjualan) = YEAR(CURDATE())")->fetch_assoc();
            
            // Total transaksi
            $transactions = $conn->query("SELECT COUNT(*) as count FROM penjualan")->fetch_assoc();
            
            // Total produk
            $products = $conn->query("SELECT COUNT(*) as count FROM produk")->fetch_assoc();
            
            // Produk stok rendah
            $lowStock = $conn->query("SELECT COUNT(*) as count FROM produk WHERE stok < 10")->fetch_assoc();
            
            // Grafik pendapatan 7 hari terakhir
            $chartData = [];
            for ($i = 6; $i >= 0; $i--) {
                $date = date('Y-m-d', strtotime("-$i days"));
                $result = $conn->query("SELECT IFNULL(SUM(total_harga), 0) as total FROM penjualan WHERE DATE(tanggal_penjualan) = '$date'")->fetch_assoc();
                $chartData[] = [
                    'date' => date('d M', strtotime($date)),
                    'total' => floatval($result['total'])
                ];
            }
            
            // Top produk terlaris
            $topProducts = $conn->query("
                SELECT p.nama_produk, SUM(dp.jumlah_produk) as total_terjual, SUM(dp.subtotal) as total_pendapatan
                FROM detail_penjualan dp
                JOIN produk p ON dp.produk_id = p.produk_id
                GROUP BY dp.produk_id
                ORDER BY total_terjual DESC
                LIMIT 10
            ")->fetch_all(MYSQLI_ASSOC);

            // Transaksi terbaru (10 terakhir)
            $recentTransactions = $conn->query("
                SELECT p.penjualan_id, p.tanggal_penjualan, p.total_harga, p.metode_pembayaran, 
                       IFNULL(pl.nama_pelanggan, 'Umum') as nama_pelanggan
                FROM penjualan p
                LEFT JOIN pelanggan pl ON p.pelanggan_id = pl.pelanggan_id
                ORDER BY p.tanggal_penjualan DESC
                LIMIT 10
            ")->fetch_all(MYSQLI_ASSOC);

            $response = [
                'success' => true,
                'stats' => [
                    'today' => floatval($today['total']),
                    'month' => floatval($month['total']),
                    'transactions' => intval($transactions['count']),
                    'products' => intval($products['count']),
                    'lowStock' => intval($lowStock['count'])
                ],
                'chart' => $chartData,
                'topProducts' => $topProducts,
                'recentTransactions' => $recentTransactions
            ];
            break;

        // KATEGORI
        case 'get_kategori':
            $result = $conn->query("SELECT * FROM kategori ORDER BY nama_kategori ASC");
            $response = ['success' => true, 'data' => $result->fetch_all(MYSQLI_ASSOC)];
            break;

        // PRODUK
        case 'get_produk':
            $query = "SELECT p.*, k.nama_kategori, k.icon as kategori_icon 
                      FROM produk p 
                      LEFT JOIN kategori k ON p.kategori_id = k.kategori_id 
                      ORDER BY p.nama_produk ASC";
            $result = $conn->query($query);
            $response = ['success' => true, 'data' => $result->fetch_all(MYSQLI_ASSOC)];
            break;

        case 'add_produk':
            $nama = $_POST['nama_produk'] ?? '';
            $harga = $_POST['harga'] ?? 0;
            $stok = $_POST['stok'] ?? 0;
            $kategori_id = $_POST['kategori_id'] ?? 1;
            
            if (empty($nama)) {
                $response = ['success' => false, 'message' => 'Nama produk harus diisi'];
                break;
            }
            
            $stmt = $conn->prepare("INSERT INTO produk (nama_produk, kategori_id, harga, stok) VALUES (?, ?, ?, ?)");
            $stmt->bind_param("sidi", $nama, $kategori_id, $harga, $stok);
            
            if ($stmt->execute()) {
                $response = ['success' => true, 'message' => 'Produk berhasil ditambahkan'];
            } else {
                $response = ['success' => false, 'message' => 'Gagal menambahkan produk'];
            }
            $stmt->close();
            break;

        case 'update_produk':
            $id = $_POST['produk_id'] ?? 0;
            $nama = $_POST['nama_produk'] ?? '';
            $harga = $_POST['harga'] ?? 0;
            $stok = $_POST['stok'] ?? 0;
            $kategori_id = $_POST['kategori_id'] ?? 1;
            
            if (empty($nama)) {
                $response = ['success' => false, 'message' => 'Nama produk harus diisi'];
                break;
            }
            
            $stmt = $conn->prepare("UPDATE produk SET nama_produk=?, kategori_id=?, harga=?, stok=? WHERE produk_id=?");
            $stmt->bind_param("sidii", $nama, $kategori_id, $harga, $stok, $id);
            
            if ($stmt->execute()) {
                $response = ['success' => true, 'message' => 'Produk berhasil diupdate'];
            } else {
                $response = ['success' => false, 'message' => 'Gagal update produk'];
            }
            $stmt->close();
            break;

        case 'delete_produk':
            $id = intval($_POST['produk_id'] ?? 0);
            
            if ($id <= 0) {
                $response = ['success' => false, 'message' => 'ID produk tidak valid'];
                break;
            }
            
            // Cek apakah produk pernah dijual
            $check = $conn->query("SELECT COUNT(*) as count FROM detail_penjualan WHERE produk_id = $id")->fetch_assoc();
            if ($check['count'] > 0) {
                $response = ['success' => false, 'message' => 'Produk tidak dapat dihapus karena sudah pernah dijual'];
                break;
            }
            
            $stmt = $conn->prepare("DELETE FROM produk WHERE produk_id=?");
            $stmt->bind_param('i', $id);
            $ok = $stmt->execute();
            $stmt->close();
            
            $response = ['success' => (bool)$ok, 'message' => $ok ? 'Produk dihapus' : 'Gagal menghapus produk'];
            break;

        // PELANGGAN
        case 'get_pelanggan':
            $res = $conn->query("SELECT * FROM pelanggan ORDER BY nama_pelanggan");
            $data = $res->fetch_all(MYSQLI_ASSOC);
            $response = ['success' => true, 'data' => $data];
            break;

        case 'add_pelanggan':
            $nama = $conn->real_escape_string(trim($_POST['nama_pelanggan'] ?? ''));
            $telp = $conn->real_escape_string(trim($_POST['nomor_telepon'] ?? ''));
            $alamat = $conn->real_escape_string(trim($_POST['alamat'] ?? ''));
            
            if (empty($nama)) {
                $response = ['success' => false, 'message' => 'Nama pelanggan harus diisi'];
                break;
            }
            
            $stmt = $conn->prepare("INSERT INTO pelanggan (nama_pelanggan, nomor_telepon, alamat) VALUES (?, ?, ?)");
            $stmt->bind_param('sss', $nama, $telp, $alamat);
            $ok = $stmt->execute();
            $stmt->close();
            
            $response = ['success' => (bool)$ok, 'message' => $ok ? 'Pelanggan ditambahkan' : 'Gagal menambah pelanggan'];
            break;

        case 'update_pelanggan':
            $id = intval($_POST['pelanggan_id'] ?? 0);
            $nama = $conn->real_escape_string(trim($_POST['nama_pelanggan'] ?? ''));
            $telp = $conn->real_escape_string(trim($_POST['nomor_telepon'] ?? ''));
            $alamat = $conn->real_escape_string(trim($_POST['alamat'] ?? ''));
            
            if ($id <= 0) {
                $response = ['success' => false, 'message' => 'ID pelanggan tidak valid'];
                break;
            }
            if (empty($nama)) {
                $response = ['success' => false, 'message' => 'Nama pelanggan harus diisi'];
                break;
            }
            
            $stmt = $conn->prepare("UPDATE pelanggan SET nama_pelanggan=?, nomor_telepon=?, alamat=? WHERE pelanggan_id=?");
            $stmt->bind_param('sssi', $nama, $telp, $alamat, $id);
            $ok = $stmt->execute();
            $stmt->close();
            
            $response = ['success' => (bool)$ok, 'message' => $ok ? 'Pelanggan diperbarui' : 'Gagal memperbarui pelanggan'];
            break;

        case 'delete_pelanggan':
            $id = intval($_POST['pelanggan_id'] ?? 0);
            
            if ($id <= 0) {
                $response = ['success' => false, 'message' => 'ID pelanggan tidak valid'];
                break;
            }
            
            // Cek apakah pelanggan pernah transaksi
            $check = $conn->query("SELECT COUNT(*) as count FROM penjualan WHERE pelanggan_id = $id")->fetch_assoc();
            if ($check['count'] > 0) {
                $response = ['success' => false, 'message' => 'Pelanggan tidak dapat dihapus karena memiliki riwayat transaksi'];
                break;
            }
            
            $stmt = $conn->prepare("DELETE FROM pelanggan WHERE pelanggan_id=?");
            $stmt->bind_param('i', $id);
            $ok = $stmt->execute();
            $stmt->close();
            
            $response = ['success' => (bool)$ok, 'message' => $ok ? 'Pelanggan dihapus' : 'Gagal menghapus pelanggan'];
            break;

        // PENJUALAN / CHECKOUT
        case 'checkout':
            $pelanggan_id = $_POST['pelanggan_id'] ?? '';
            $total = $_POST['total'] ?? 0;
            $diskon = $_POST['diskon'] ?? 0;
            $ppn = $_POST['ppn'] ?? 0;
            $grand_total = $_POST['grand_total'] ?? $total;
            $cart = json_decode($_POST['cart'] ?? '[]', true);
            $metode = $_POST['metode_pembayaran'] ?? 'cash';

            if (empty($cart)) {
                $response = ['success' => false, 'message' => 'Keranjang kosong'];
                break;
            }

            // Validasi stok
            foreach ($cart as $item) {
                $stmt = $conn->prepare("SELECT stok FROM produk WHERE produk_id = ?");
                $stmt->bind_param("i", $item['produk_id']);
                $stmt->execute();
                $result = $stmt->get_result();
                $produk = $result->fetch_assoc();
                $stmt->close();
                
                if (!$produk || $produk['stok'] < $item['jumlah']) {
                    $response = [
                        'success' => false, 
                        'message' => 'Stok ' . ($item['nama_produk'] ?? 'produk') . ' tidak mencukupi'
                    ];
                    break 2;
                }
            }

            $conn->begin_transaction();

            try {
                $pelanggan_id_val = empty($pelanggan_id) ? null : $pelanggan_id;
                
                $stmt = $conn->prepare("INSERT INTO penjualan (pelanggan_id, tanggal_penjualan, total_harga, diskon, ppn, grand_total, metode_pembayaran) VALUES (?, NOW(), ?, ?, ?, ?, ?)");
                $stmt->bind_param("idddds", $pelanggan_id_val, $total, $diskon, $ppn, $grand_total, $metode);
                
                if (!$stmt->execute()) {
                    throw new Exception("Gagal menyimpan penjualan: " . $stmt->error);
                }
                
                $penjualan_id = $conn->insert_id;
                $stmt->close();

                $stmt_detail = $conn->prepare("INSERT INTO detail_penjualan (penjualan_id, produk_id, jumlah_produk, subtotal) VALUES (?, ?, ?, ?)");
                $stmt_update = $conn->prepare("UPDATE produk SET stok = stok - ? WHERE produk_id = ?");

                foreach ($cart as $item) {
                    $stmt_detail->bind_param("iiid", 
                        $penjualan_id, 
                        $item['produk_id'], 
                        $item['jumlah'], 
                        $item['subtotal']
                    );
                    
                    if (!$stmt_detail->execute()) {
                        throw new Exception("Gagal menyimpan detail: " . $stmt_detail->error);
                    }

                    $stmt_update->bind_param("ii", $item['jumlah'], $item['produk_id']);
                    
                    if (!$stmt_update->execute()) {
                        throw new Exception("Gagal update stok: " . $stmt_update->error);
                    }
                }

                $stmt_detail->close();
                $stmt_update->close();

                $conn->commit();
                
                $response = [
                    'success' => true, 
                    'message' => 'Checkout berhasil',
                    'penjualan_id' => $penjualan_id
                ];
                
            } catch (Exception $e) {
                $conn->rollback();
                error_log("Checkout error: " . $e->getMessage());
                $response = ['success' => false, 'message' => 'Gagal checkout: ' . $e->getMessage()];
            }
            break;

        case 'get_penjualan':
            $sql = "SELECT p.*, pl.nama_pelanggan 
                    FROM penjualan p 
                    LEFT JOIN pelanggan pl ON p.pelanggan_id = pl.pelanggan_id 
                    ORDER BY p.tanggal_penjualan DESC 
                    LIMIT 100";
            $result = $conn->query($sql);
            $data = [];
            while ($row = $result->fetch_assoc()) {
                $data[] = $row;
            }
            $response = ['success' => true, 'data' => $data];
            break;

        case 'get_detail_penjualan':
            $id = intval($_POST['penjualan_id'] ?? 0);
            
            if ($id <= 0) {
                $response = ['success' => false, 'message' => 'ID penjualan tidak valid'];
                break;
            }
            
            $stmt = $conn->prepare("SELECT dp.*, pr.nama_produk FROM detail_penjualan dp JOIN produk pr ON dp.produk_id = pr.produk_id WHERE dp.penjualan_id = ?");
            $stmt->bind_param('i', $id);
            $stmt->execute();
            $result = $stmt->get_result();
            $data = $result->fetch_all(MYSQLI_ASSOC);
            $stmt->close();
            
            $response = ['success' => true, 'data' => $data];
            break;
            
        // HOLD TRANSACTION
        case 'hold_transaction':
            $pelanggan_id = $_POST['pelanggan_id'] ?? null;
            $cart = $_POST['cart'] ?? '';
            $total = $_POST['total'] ?? 0;
            
            $stmt = $conn->prepare("INSERT INTO hold_transaction (pelanggan_id, cart_data, total) VALUES (?, ?, ?)");
            $stmt->bind_param("isd", $pelanggan_id, $cart, $total);
            
            if ($stmt->execute()) {
                $response = ['success' => true, 'message' => 'Transaksi berhasil di-hold', 'hold_id' => $conn->insert_id];
            } else {
                $response = ['success' => false, 'message' => 'Gagal hold transaksi'];
            }
            $stmt->close();
            break;

        case 'get_hold_transactions':
            $query = "SELECT h.*, p.nama_pelanggan 
                      FROM hold_transaction h 
                      LEFT JOIN pelanggan p ON h.pelanggan_id = p.pelanggan_id 
                      ORDER BY h.created_at DESC";
            $result = $conn->query($query);
            $response = ['success' => true, 'data' => $result->fetch_all(MYSQLI_ASSOC)];
            break;

        case 'resume_hold':
            $hold_id = $_POST['hold_id'] ?? 0;
            
            $stmt = $conn->prepare("SELECT * FROM hold_transaction WHERE hold_id = ?");
            $stmt->bind_param("i", $hold_id);
            $stmt->execute();
            $result = $stmt->get_result();
            $data = $result->fetch_assoc();
            $stmt->close();
            
            if ($data) {
                // Delete hold after resume
                $stmt = $conn->prepare("DELETE FROM hold_transaction WHERE hold_id = ?");
                $stmt->bind_param("i", $hold_id);
                $stmt->execute();
                $stmt->close();
                
                $response = ['success' => true, 'data' => $data];
            } else {
                $response = ['success' => false, 'message' => 'Data tidak ditemukan'];
            }
            break;

        case 'delete_hold':
            $hold_id = $_POST['hold_id'] ?? 0;
            
            $stmt = $conn->prepare("DELETE FROM hold_transaction WHERE hold_id = ?");
            $stmt->bind_param("i", $hold_id);
            
            if ($stmt->execute()) {
                $response = ['success' => true, 'message' => 'Hold transaction berhasil dihapus'];
            } else {
                $response = ['success' => false, 'message' => 'Gagal menghapus'];
            }
            $stmt->close();
            break;

        default:
            $response = ['success' => false, 'message' => 'Action tidak dikenali'];
            break;
    }
} catch (Throwable $e) {
    error_log('[API] ' . $e->getMessage());
    $response = ['success' => false, 'message' => 'Server error'];
}

echo json_encode($response);
exit;